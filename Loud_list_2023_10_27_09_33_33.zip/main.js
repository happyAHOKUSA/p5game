function setup(){
  let a = new Canvas(200,200)
  console.log(a)
  background(0);
}